# backend/src/app/inventory/services/items.py

from typing import List, Optional
from uuid import UUID

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from src.app.inventory.models.item_models import Item
from src.app.core.base_repository import BaseRepository


class ItemService(BaseRepository[Item]):
    def __init__(self) -> None:
        super().__init__(Item)

    async def get_by_org(
        self,
        session: AsyncSession,
        org_id: UUID,
        limit: int = 100,
        offset: int = 0,
    ) -> List[Item]:
        stmt = (
            select(Item)
            .where(
                Item.org_id == org_id,
                Item.deleted_at.is_(None),
            )
            .order_by(Item.name.asc())
            .limit(limit)
            .offset(offset)
        )
        result = await session.execute(stmt)
        return result.scalars().all()

    async def get_by_id(
        self,
        session: AsyncSession,
        item_id: UUID,
    ) -> Optional[Item]:
        stmt = select(Item).where(
            Item.item_id == item_id,
            Item.deleted_at.is_(None),
        )
        result = await session.execute(stmt)
        return result.scalar_one_or_none()

    async def delete_item(
        self,
        session: AsyncSession,
        item_id: UUID,
    ) -> Optional[Item]:
        """Soft-delete via BaseRepository logic."""
        return await self.delete(session, item_id)


item_service = ItemService()
