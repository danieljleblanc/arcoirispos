"""Add rounding_apply_to column to organization_settings

Revision ID: 3d23faeb49c5
Revises: 946cda79dd2f
Create Date: 2025-11-29 00:00:00
"""

from alembic import op
import sqlalchemy as sa


# Revision identifiers.
revision = "3d23faeb49c5"
down_revision = "946cda79dd2f"   # <-- ensure correct dependency
branch_labels = None
depends_on = None


def upgrade():
    # IMPORTANT:
    # Use create_type=False so Alembic does not try to re-create
    # an enum that already exists (it was created in the previous migration).
    rounding_targets_enum = sa.Enum(
        "none", "cash_only", "all_payments",
        name="rounding_targets",
        create_type=False
    )

    op.add_column(
        "organization_settings",
        sa.Column(
            "rounding_apply_to",
            rounding_targets_enum,
            nullable=False,
            server_default=sa.text("'cash_only'"),
        ),
        schema="core",
    )


def downgrade():
    op.drop_column(
        "organization_settings",
        "rounding_apply_to",
        schema="core"
    )
    # Do NOT drop the enum here — previous migration owns the enum type.
