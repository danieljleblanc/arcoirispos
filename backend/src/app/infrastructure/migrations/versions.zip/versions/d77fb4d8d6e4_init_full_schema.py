"""
Init full schema

Revision ID: d77fb4d8d6e4
Revises: 000000000002
"""

from typing import Sequence, Union

from alembic import op
from sqlalchemy import create_engine

from src.app.core.base import Base
from src.app.core.config import settings

# --- IMPORT ALL MODELS HERE ---
# Without these imports, Base.metadata is empty at migration time.

from src.app.org.models import (
    organization_models,
    role_models,
    user_models,
)

from src.app.accounting.models import (
    account_models,
    bank_account_models,
    customer_balance_models,
    journal_models,
    journal_line_models,
)

from src.app.inventory.models import (
    item_models,
    location_models,
    stock_level_models,
    stock_movement_models,
)

from src.app.pos.models import (
    customer_models,
    payment_models,
    sale_models,
    terminal_models,
    tax_rate_models,
)

revision: str = "d77fb4d8d6e4"
down_revision: Union[str, Sequence[str], None] = "000000000002"
branch_labels = None
depends_on = None


def upgrade() -> None:
    # Ensure schemas exist
    op.execute("CREATE SCHEMA IF NOT EXISTS core")
    op.execute("CREATE SCHEMA IF NOT EXISTS acct")
    op.execute("CREATE SCHEMA IF NOT EXISTS inv")
    op.execute("CREATE SCHEMA IF NOT EXISTS pos")

    # Build engine
    engine = create_engine(settings.database_url)

    # Create all tables — now that all models are imported
    Base.metadata.create_all(bind=engine)


def downgrade() -> None:
    engine = create_engine(settings.database_url)
    Base.metadata.drop_all(bind=engine)
