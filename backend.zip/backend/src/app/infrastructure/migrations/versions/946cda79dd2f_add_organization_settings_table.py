"""Add organization_settings table (corrected)

Revision ID: 946cda79dd2f
Revises: 
Create Date: 2025-11-29 00:00:00
"""

from alembic import op
import sqlalchemy as sa


# Revision identifiers, used by Alembic.
revision = "946cda79dd2f"
down_revision = None
branch_labels = None
depends_on = None


def upgrade():
    # --- ENUMS --------------------------------------------------------------
    # Rounding mode enum
    rounding_mode_enum = sa.Enum(
        "none", "nickel", "dime", "quarter", "dollar",
        name="rounding_mode"
    )

    # Rounding apply-to enum
    # This enum is also used in the second migration, but declaring here is safe
    rounding_targets_enum = sa.Enum(
        "none", "cash_only", "all_payments",
        name="rounding_targets"
    )

    # Inventory mode enum
    inventory_mode_enum = sa.Enum(
        "deduct_on_cart", "deduct_on_sale",
        name="inventory_mode"
    )

    # Create enums in DB
    rounding_mode_enum.create(op.get_bind(), checkfirst=True)
    rounding_targets_enum.create(op.get_bind(), checkfirst=True)
    inventory_mode_enum.create(op.get_bind(), checkfirst=True)

    # --- TABLE --------------------------------------------------------------
    op.create_table(
        "organization_settings",
        sa.Column(
            "settings_id",
            sa.UUID(),
            primary_key=True,
            server_default=sa.text("gen_random_uuid()"),
            nullable=False,
        ),
        sa.Column(
            "org_id",
            sa.UUID(),
            sa.ForeignKey("core.organizations.org_id", ondelete="CASCADE"),
            nullable=False,
        ),
        sa.Column(
            "rounding_mode",
            rounding_mode_enum,
            nullable=False,
            server_default=sa.text("'none'")
        ),
        # Added here; second migration will override/modify as needed
        sa.Column(
            "rounding_apply_to",
            rounding_targets_enum,
            nullable=False,
            server_default=sa.text("'cash_only'")
        ),
        sa.Column(
            "inventory_mode",
            inventory_mode_enum,
            nullable=False,
            server_default=sa.text("'deduct_on_cart'")
        ),

        sa.Column(
            "created_at",
            sa.DateTime(timezone=True),
            server_default=sa.text("NOW()"),
            nullable=False,
        ),
        sa.Column(
            "updated_at",
            sa.DateTime(timezone=True),
            server_default=sa.text("NOW()"),
            nullable=False,
        ),

        schema="core",
    )


def downgrade():
    op.drop_table("organization_settings", schema="core")

    # Drop enums
    op.execute("DROP TYPE IF EXISTS core.rounding_mode")
    op.execute("DROP TYPE IF EXISTS core.rounding_targets")
    op.execute("DROP TYPE IF EXISTS core.inventory_mode")
